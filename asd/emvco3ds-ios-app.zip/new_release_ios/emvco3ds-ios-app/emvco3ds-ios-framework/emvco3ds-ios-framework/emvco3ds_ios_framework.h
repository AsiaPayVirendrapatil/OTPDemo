//
//  emvco3ds_ios_framework.h
//  emvco3ds-ios-framework
//
//  Created by Van Drongelen, Mike on 03/08/2018.
//  Copyright © 2018 UL. All rights reserved.
//

#include <UIKit/UIKit.h>

//! Project version number for emvco3ds_ios_framework.
FOUNDATION_EXPORT double emvco3ds_ios_frameworkVersionNumber;

//! Project version string for emvco3ds_ios_framework.
FOUNDATION_EXPORT const unsigned char emvco3ds_ios_frameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <emvco3ds_ios_framework/PublicHeader.h>


