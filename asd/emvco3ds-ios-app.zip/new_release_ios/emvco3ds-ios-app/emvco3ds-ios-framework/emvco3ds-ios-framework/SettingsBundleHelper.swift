//
//  SettingsBundleHelper.swift
//  emvco3ds-ios-framework
//
//  Created by Camargo, Vinicius on 13/09/2018.
//  Copyright © 2018 UL. All rights reserved.
//

import Foundation
class SettingsBundleHelper {
    struct SettingsBundleKeys {
        static let autoSubmitChallenges = "auto_submit_challenges"
    }
}
