//  LogMessage.swift
//  emvco3ds-ios-app
//
//  Copyright © 2018 UL Transaction Security. All rights reserved.

import UIKit

public class LogMessage: NSObject {
    public var level: String = ""
    public var message: String = ""
}
