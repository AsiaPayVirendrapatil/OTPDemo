//
//  SingleSelelctorChallengeProtocol.swift
//  emvco3ds_protocols_ios
//
//  Created by Kinaan, William on 16/08/2017.
//  

import UIKit

@objc public protocol SingleSelectorChallengeProtocol : GenericChallengeProtocol{
     func selectObject (_ index : Int)
}
