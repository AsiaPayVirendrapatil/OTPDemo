//
//  SDKChallengeProtocol.swift
//  emvco3ds_protocols_ios
//
//  Created by Camargo, Vinicius on 12/13/17.
//

import UIKit

@objc public protocol SDKChallengeProtocol {
    func handleChallenge();
}
