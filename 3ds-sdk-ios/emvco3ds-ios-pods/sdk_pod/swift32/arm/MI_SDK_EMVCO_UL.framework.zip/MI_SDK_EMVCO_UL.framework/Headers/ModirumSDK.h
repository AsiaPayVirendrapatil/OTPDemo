#import <Foundation/Foundation.h>
#import "Merchant.h"

@interface ModirumSDK : NSObject

- (id<Merchant>) getMerchant;

@end
