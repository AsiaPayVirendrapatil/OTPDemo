//
//  Asiapay_alipay_sdk
//  Created by Virendra patil on 05/03/19.
//  Copyright © 2019 Virendra patil. All rights reserved.

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Wrapper : NSObject  {
}

- (void) getWrapped : (NSString *) param;

@end

NS_ASSUME_NONNULL_END




