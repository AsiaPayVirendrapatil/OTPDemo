//  Asiapay_alipay_sdk.h
//  Asiapay_alipay_sdk
//  Created by Virendra patil on 01/03/19.
//  Copyright © 2019 Virendra patil. All rights reserved.


#import <UIKit/UIKit.h>
#import "Wrapper.h"

//! Project version number for Asiapay_alipay_sdk.
FOUNDATION_EXPORT double Asiapay_alipay_sdkVersionNumber;

//! Project version string for Asiapay_alipay_sdk.
FOUNDATION_EXPORT const unsigned char Asiapay_alipay_sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Asiapay_alipay_sdk/PublicHeader.h>



