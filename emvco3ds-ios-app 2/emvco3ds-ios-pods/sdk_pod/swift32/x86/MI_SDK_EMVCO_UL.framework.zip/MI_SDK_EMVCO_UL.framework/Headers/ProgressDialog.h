#import <UIKit/UIKit.h>

@protocol ProgressDialog
- (void) start;
- (void) stop;
@end
