//
//  asiapay_3ds.h
//  asiapay_3ds
//
//  Created by Virendra patil on 20/06/19.
//  Copyright © 2019 Virendra patil. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "isDebugged.h"
#include <assert.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/sysctl.h>
#import <Security/Security.h>
#import <CommonCrypto/CommonHMAC.h>
#import <tgmath.h>

//! Project version number for asiapay_3ds.
FOUNDATION_EXPORT double asiapay_3dsVersionNumber;

//! Project version string for asiapay_3ds.
FOUNDATION_EXPORT const unsigned char asiapay_3dsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <asiapay_3ds/PublicHeader.h>


